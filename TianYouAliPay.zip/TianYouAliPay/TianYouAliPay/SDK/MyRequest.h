//
//  MyRequest.h
//  MyRequest
//
//  Created by hx on 14-11-27.
//  Copyright (c) 2014年  hx rights reserved.
//

#import <Foundation/Foundation.h>
@class MyRequest;

@protocol MyRequestDelegate <NSObject>
    //声明一个协议方法，请求结束时用来传值。
- (void)request:(MyRequest *)request didFinishWithData:(NSData *)data;

@end

@interface MyRequest : NSObject<NSURLConnectionDataDelegate>{
    NSMutableData       *_data;
}

@property (nonatomic,assign)id<MyRequestDelegate> delegate;

-(id)initWithURL:(NSString *)url delegate:(id<MyRequestDelegate>)delegate;
-(void)startGETRequest;
- (void)startZFBPostRequestWithParamString:(NSString *)phoneNumber;


@end