//
//  MyRequest.m
//  MyRequest
//
//  Created by hx on 14-11-27.
//  Copyright (c) 2014年 hx All rights reserved.
//

#import "MyRequest.h"

//类的扩展，可以添加新的属性和方法。
@interface MyRequest()
@property (nonatomic,retain)NSString *url;
@end

@implementation MyRequest


-(id)initWithURL:(NSString *)url delegate:(id<MyRequestDelegate>)delegate{
    self = [super init];
    if (self) {
        _data = [[NSMutableData alloc] init];
        self.url = url;
        self.delegate = delegate;
    }
    return self;
}
-(void)startGETRequest
{
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:self.url]];
    [request setHTTPMethod:@"GET"];
    NSURLConnection *connection = [NSURLConnection connectionWithRequest:request delegate:self];
    [connection start];
}
//支付宝请求
- (void)startZFBPostRequestWithParamString:(NSString *)phoneNumber{
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:self.url]];
    //NSData *data = [param dataUsingEncoding:NSUTF8StringEncoding];
    NSString *dataStr=[NSString stringWithFormat:@"src=3&agent=170&channel=6&uid=%@&goodsid=90120&money=0.01",phoneNumber];
    NSData *data = [dataStr dataUsingEncoding:NSUTF8StringEncoding];
    [request setHTTPBody:data];
    [request setHTTPMethod:@"POST"];
    NSURLConnection *connection = [NSURLConnection connectionWithRequest:request delegate:self];
    [connection start];
}

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response{
    [_data setData:[NSData data]];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data{
    [_data appendData:data];
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection{

    [self.delegate request:self didFinishWithData:_data];

}
-(void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
     NSLog(@"请求失败%@",error.localizedDescription);
}

@end