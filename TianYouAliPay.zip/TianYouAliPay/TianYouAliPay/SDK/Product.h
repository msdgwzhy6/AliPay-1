//
//  Product.h
//  WecareFuture
//
//  Created by wecare002 on 15/5/5.
//  Copyright (c) 2015年 wecare. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Product : NSObject
{
@private
    float     _price;
    NSString *_subject;
    NSString *_body;
    NSString *_orderId;
}
@property (nonatomic, assign) float price;
@property (nonatomic, strong) NSString *subject;
@property (nonatomic, strong) NSString *body;
@property (nonatomic, strong) NSString *orderId;
@end
