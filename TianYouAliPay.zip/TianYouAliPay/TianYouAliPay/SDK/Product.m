//
//  Product.m
//  WecareFuture
//
//  Created by wecare002 on 15/5/5.
//  Copyright (c) 2015年 wecare. All rights reserved.
//

#import "Product.h"

@implementation Product

@end
