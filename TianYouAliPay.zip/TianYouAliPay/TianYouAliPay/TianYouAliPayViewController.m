//
//  TianYouAliPayViewController.m
//  TianYouAliPay
//
//  Created by TianYou on 16/5/16.
//  Copyright © 2016年 hiservice_tech. All rights reserved.
//

#import "TianYouAliPayViewController.h"
#import <AlipaySDK/AlipaySDK.h>
#import "Product.h"
#import "APAuthV2Info.h"
#import "Order.h"
#import "DataSigner.h"

@interface TianYouAliPayViewController ()

@end

@implementation TianYouAliPayViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.navigationItem.title = @"支付宝支付Demo";
    
    UIButton * payButton = [UIButton buttonWithType:UIButtonTypeCustom];
    payButton.frame = CGRectMake(100, 200, 200, 100);
    [payButton setTitle:@"支付0.01元" forState:UIControlStateNormal];
    payButton.backgroundColor = [UIColor redColor];
    [payButton addTarget:self action:@selector(payButtonClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:payButton];
}
//点击支付
-(void)payButtonClick
{
    NSLog(@"点击了支付宝支付");
    [self treasurePay];
}
//发起支付
-(void)treasurePay
{
    /*
     *点击获取prodcut实例并初始化订单信息
     */
    Product *product = [[Product alloc] init];
    //将服务器的订单价格赋值
    product.price = 0.01;//价格
    product.subject = @"商品标题";//标题
    product.body = @"商品描述";//描述
    //product.orderId = self.orderID;
    //NSLog(@"product.orderId=%@",product.orderId);
    /*
     *商户的唯一的parnter和seller。
     *签约后，支付宝会为每个商户分配一个唯一的 parnter 和 seller。
     */
    /*============================================================================*/
    /*=======================需要填写商户app申请的===================================*/
    /*============================================================================*/
    
    //合作伙伴
    NSString *partner = @"";
    //卖方
    NSString *seller = @"";
    //私钥
    NSString *privateKey = @"";
    
    NSLog(@"私钥的长度:%lu",(unsigned long)privateKey.length);
    
    /*============================================================================*/
    /*============================================================================*/
    /*============================================================================*/
    
    //partner和seller获取失败,提示
    if ([partner length] == 0 ||
        [seller length] == 0 ||
        [privateKey length] == 0)
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提示"
                                                        message:@"缺少partner或者seller或者私钥。"
                                                       delegate:self
                                              cancelButtonTitle:@"确定"
                                              otherButtonTitles:nil];
        [alert show];
        return;
    }
    /*
     *生成订单信息及签名
     */
    //将商品信息赋予AlixPayOrder的成员变量
    Order *order = [[Order alloc] init];
    order.partner = partner;
    order.seller = seller;
    order.tradeNO = @"20160516103651666666"; //订单ID（由商家自行制定）
    order.productName = product.subject; //商品标题
    order.productDescription = product.body; //商品描述
    order.amount = [NSString stringWithFormat:@"%.2f",product.price]; //商品价格
    order.notifyURL =  @"www.baidu.com"; //回调URL
    
    order.service = @"mobile.securitypay.pay";
    order.paymentType = @"1";
    order.inputCharset = @"utf-8";
    order.itBPay = @"30m";
    order.showUrl = @"m.alipay.com";
    
    //应用注册scheme,在AlixPayDemo-Info.plist定义URL types
    NSString *appScheme = @"zfb2016428";
    
    //将商品信息拼接成字符串
    NSString *orderSpec = [order description];
    NSLog(@"orderSpec = %@",orderSpec);
    
    //获取私钥并将商户信息签名,外部商户可以根据情况存放私钥和签名,只需要遵循RSA签名规范,并将签名字符串base64编码和UrlEncode
    id<DataSigner> signer = CreateRSADataSigner(privateKey);
    NSString *signedString = [signer signString:orderSpec];
    
    //将签名成功字符串格式化为订单字符串,请严格按照该格式
    NSString *orderString = nil;
    if (signedString != nil) {
        orderString = [NSString stringWithFormat:@"%@&sign=\"%@\"&sign_type=\"%@\"",
                       orderSpec, signedString, @"RSA"];
        
        [[AlipaySDK defaultService] payOrder:orderString fromScheme:appScheme callback:^(NSDictionary *resultDic) {
            NSLog(@"页面返回的结果 = %@",resultDic);
            //判断
            NSString * resultStatus = resultDic[@"resultStatus"];
            NSLog(@"状态码:%@",resultStatus);
            if ([resultStatus isEqualToString:@"9000"])//成功
            {//跳转成功页面
               
            }else if ([resultStatus isEqualToString:@"6001"])//用户取消
            {//跳转全部订单页面
                
            }
            
        }];
    }
    
}








- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
