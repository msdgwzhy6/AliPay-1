//
//  TianYouAliPayViewController.h
//  TianYouAliPay
//
//  Created by TianYou on 16/5/16.
//  Copyright © 2016年 hiservice_tech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TianYouAliPayViewController : UIViewController

@end
